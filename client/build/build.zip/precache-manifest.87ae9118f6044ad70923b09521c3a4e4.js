self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e319248117de0ba8c9b9d6e1599fa8c5",
    "url": "/YH-Clothing/index.html"
  },
  {
    "revision": "17a94ed47a70719f5319",
    "url": "/YH-Clothing/static/css/4.9905d55a.chunk.css"
  },
  {
    "revision": "a0bf4ea94fcb6979a771",
    "url": "/YH-Clothing/static/css/main.8ff59cd9.chunk.css"
  },
  {
    "revision": "2f87e38f925d7f350d97",
    "url": "/YH-Clothing/static/js/10.645ca929.chunk.js"
  },
  {
    "revision": "d747334fe1f9e394ce5a",
    "url": "/YH-Clothing/static/js/2.e9e23d31.chunk.js"
  },
  {
    "revision": "c608fb72bff51f1d457ebafb893fb94c",
    "url": "/YH-Clothing/static/js/2.e9e23d31.chunk.js.LICENSE.txt"
  },
  {
    "revision": "1adc2819b679e96772b8",
    "url": "/YH-Clothing/static/js/3.4952ef82.chunk.js"
  },
  {
    "revision": "17a94ed47a70719f5319",
    "url": "/YH-Clothing/static/js/4.daaa5eae.chunk.js"
  },
  {
    "revision": "33ac7df1e6fe4752eab1",
    "url": "/YH-Clothing/static/js/5.1bfbe0fd.chunk.js"
  },
  {
    "revision": "6fc5975976645eb527ee",
    "url": "/YH-Clothing/static/js/6.61cdea92.chunk.js"
  },
  {
    "revision": "d80a967d65562e8ac46b11937d3ba69e",
    "url": "/YH-Clothing/static/js/6.61cdea92.chunk.js.LICENSE.txt"
  },
  {
    "revision": "3ea898dc739490a76d64",
    "url": "/YH-Clothing/static/js/7.dd995b7f.chunk.js"
  },
  {
    "revision": "9afdd5beba3fda27ffab",
    "url": "/YH-Clothing/static/js/8.0ba39346.chunk.js"
  },
  {
    "revision": "e83a904bc274add7f387",
    "url": "/YH-Clothing/static/js/9.1a5cb316.chunk.js"
  },
  {
    "revision": "a0bf4ea94fcb6979a771",
    "url": "/YH-Clothing/static/js/main.e5021140.chunk.js"
  },
  {
    "revision": "32f087dba79bf611660069a68c00c0b9",
    "url": "/YH-Clothing/static/js/main.e5021140.chunk.js.LICENSE.txt"
  },
  {
    "revision": "3fac6d20b8792471ee47",
    "url": "/YH-Clothing/static/js/runtime-main.e1a10f81.js"
  },
  {
    "revision": "a5a86f179f4af64b0b25366f320034db",
    "url": "/YH-Clothing/static/media/YousfitnessLogo.a5a86f17.png"
  },
  {
    "revision": "4cf00bda865a0838149ed7fcc67c235a",
    "url": "/YH-Clothing/static/media/if.4cf00bda.png"
  },
  {
    "revision": "30f0707118fb960665491424c115ac44",
    "url": "/YH-Clothing/static/media/shopping-bag.30f07071.svg"
  },
  {
    "revision": "2c0663c1bd15ae55381e03234c909605",
    "url": "/YH-Clothing/static/media/team1.2c0663c1.jpg"
  },
  {
    "revision": "1e6799328bd18112242ccb5e05c77b27",
    "url": "/YH-Clothing/static/media/team2.1e679932.jpg"
  },
  {
    "revision": "c50c77465ea4c221cd3164fc11533c7a",
    "url": "/YH-Clothing/static/media/team3.c50c7746.jpg"
  },
  {
    "revision": "8b134bd92740a17d8ba8baaad87f067e",
    "url": "/YH-Clothing/static/media/wave_1.8b134bd9.gif"
  },
  {
    "revision": "bf19e90f6be153a541aea7b0d79216a9",
    "url": "/YH-Clothing/static/media/wave_2.bf19e90f.png"
  },
  {
    "revision": "26648e95ce1bd90d198e4b46d091f595",
    "url": "/YH-Clothing/static/media/wave_3.26648e95.png"
  }
]);